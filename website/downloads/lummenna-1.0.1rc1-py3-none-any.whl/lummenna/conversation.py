"""ConversationMemory: production memory loop for agentic businesses.

Orchestrates retrieve → assemble → (caller runs LLM) → store turn → log feedback.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass

from lummenna.brand.errors import FeedbackLogError
from lummenna.config import LummennaConfig
from lummenna.controller import TwinForceController
from lummenna.data.schema import get_connection
from lummenna.epistemic import EpistemicTracker
from lummenna.force.contextual.assembly import assemble_context
from lummenna.force.contextual.embed import get_embedder
from lummenna.force.mnemonic.retrieval_graph import GraphChannel
from lummenna.force.mnemonic.store import _tenant_id_supported, store_memory
from lummenna.force.mnemonic.user_profile import get_profile, update_vm_weights
from lummenna.force.mnemonic.value_model import DEFAULT_WEIGHTS, learn_weights_from_feedback
from lummenna.fusion import RetrievedChunk
from lummenna.goals import GoalTree
from lummenna.logging import get_console_logger
from lummenna.search import SearchPipeline

logger = get_console_logger(__name__)


@dataclass
class TurnResult:
    """Result of a single conversation turn."""

    assembled_context: str
    retrieved_chunks: list[RetrievedChunk]
    stored_user_chunk_id: int | None
    stored_assistant_chunk_id: int | None


class ConversationMemory:
    """Drop-in memory manager for agent conversations.

    Typical usage::

        mem = ConversationMemory(config, user_id="alice")

        # 1. Retrieve & assemble context before sending to LLM
        turn = mem.retrieve_and_assemble("What did we decide about pricing?")
        response = my_llm_call(turn.assembled_context)

        # 2. Store the turn and log implicit feedback
        mem.store_turn(
            user_msg="What did we decide about pricing?",
            assistant_msg=response,
            retrieved_chunks=turn.retrieved_chunks,
            room_name="sales",
        )

    Attributes:
        config: :class:`LummennaConfig` instance.
        conn: Shared SQLite connection (caller may manage lifecycle).
        tfc: :class:`TwinForceController` instance.
        embedder: Production embedder (raises if model missing).
        pipeline: :class:`SearchPipeline` wired with embedder.
        user_id: Multi-tenancy identifier.
        goals: Persistent :class:`GoalTree`.
        epistemic: Persistent :class:`EpistemicTracker`.
    """

    def __init__(
        self,
        config: LummennaConfig | None = None,
        conn: sqlite3.Connection | None = None,
        tfc: TwinForceController | None = None,
        embedder=None,
        user_id: str = "default",
        tenant_id: str = "default",
    ) -> None:
        self.config = config or LummennaConfig()
        self.conn = conn or get_connection(self.config)
        self.tfc = tfc or TwinForceController()
        self._own_conn = conn is None
        self.user_id = user_id
        self.tenant_id = tenant_id

        if embedder is not None:
            self.embedder = embedder
        else:
            # Raises ModelNotAvailableError unless the caller explicitly
            # opted into mock embeddings (testing only). A silent mock here
            # would make every semantic retrieval meaningless.
            self.embedder = get_embedder(self.config, allow_mock=self.config.allow_mock_embedder)

        self.pipeline = SearchPipeline(
            self.conn,
            self.config,
            tfc=self.tfc,
            embedder=self.embedder,
            graph=GraphChannel(self.conn) if GraphChannel.is_available(self.conn) else None,
        )
        self.goals = GoalTree(self.conn, user_id=user_id)
        self.epistemic = EpistemicTracker(self.conn, user_id=user_id)

        # Ensure user_profile row exists
        self._ensure_user_profile()

    def _ensure_user_profile(self) -> None:
        profile = get_profile(self.conn, self.user_id)
        if not profile:
            update_vm_weights(self.conn, self.user_id, DEFAULT_WEIGHTS.copy())
            self.conn.commit()

    def retrieve_and_assemble(
        self,
        query: str,
        active_goals: list[str] | None = None,
        system_prompt_override: str | None = None,
        top_k: int = 5,
        tenant_id: str | None = None,
    ) -> TurnResult:
        """Retrieve memories for *query* and assemble a context window.

        Args:
            query: User message or agent query string.
            active_goals: Optional list of active goal strings for boosting.
                If omitted, the persistent :attr:`goals` tree is queried.
            system_prompt_override: Replace the default palace system prompt.
            top_k: Max memories to retrieve.
            tenant_id: Optional tenant override for this request.

        Returns:
            :class:`TurnResult` containing assembled prompt and raw chunks.
        """
        goals = active_goals if active_goals is not None else self.goals.active_path_keywords()
        active_tenant = tenant_id if tenant_id is not None else self.tenant_id
        results = self.pipeline.execute(query, goal_tree_keywords=goals, tenant_id=active_tenant)
        top = results[:top_k]

        if not top:
            ctx = assemble_context(
                query,
                [],
                goals,
                self.tfc.state,
                self.config,
                token_counter=None,
                system_prompt_override=system_prompt_override,
            )
            return TurnResult(ctx, [], None, None)

        ctx = assemble_context(
            query,
            top,
            goals,
            self.tfc.state,
            self.config,
            token_counter=None,
            system_prompt_override=system_prompt_override,
        )
        return TurnResult(ctx, top, None, None)

    def store_turn(
        self,
        user_msg: str,
        assistant_msg: str,
        retrieved_chunks: list[RetrievedChunk] | None = None,
        room_name: str = "conversations",
        tenant_id: str | None = None,
    ) -> tuple[int | None, int | None]:
        """Store a conversation turn and log implicit feedback.

        Args:
            user_msg: Raw user message.
            assistant_msg: Raw assistant response.
            retrieved_chunks: Chunks that were injected into the prompt for this
                turn. Implicit positive feedback is logged for each.
            room_name: Room to store the turn in. Defaults to ``conversations``.
            tenant_id: Optional tenant override for this turn.

        Returns:
            Tuple of ``(user_chunk_id, assistant_chunk_id)``.
        """
        user_emb = self.embedder.encode_single(user_msg)
        assistant_emb = self.embedder.encode_single(assistant_msg)

        active_tenant = tenant_id if tenant_id is not None else self.tenant_id
        user_chunk_id = store_memory(
            self.conn,
            content=user_msg,
            room_name=room_name,
            source_type="user_input",
            embedding=user_emb,
            config=self.config,
            tenant_id=active_tenant,
        )
        assistant_chunk_id = store_memory(
            self.conn,
            content=assistant_msg,
            room_name=room_name,
            source_type="agent_reasoning",
            embedding=assistant_emb,
            config=self.config,
            tenant_id=active_tenant,
        )

        if retrieved_chunks:
            for rc in retrieved_chunks:
                self._log_implicit_feedback(rc.chunk_id, positive=True, tenant_id=active_tenant)

        # Mark retrieved chunk IDs as known facts
        if retrieved_chunks:
            self.epistemic.mark_known([rc.chunk_id for rc in retrieved_chunks])

        logger.info(
            "turn_stored",
            user_chunk_id=user_chunk_id,
            assistant_chunk_id=assistant_chunk_id,
            room=room_name,
            feedback_chunks=len(retrieved_chunks or []),
        )

        return user_chunk_id, assistant_chunk_id

    def log_explicit_feedback(
        self,
        chunk_id: int,
        was_useful: bool,
        user_id: str | None = None,
        feedback_type: str = "explicit",
        tenant_id: str | None = None,
    ) -> None:
        """Log explicit user feedback for a retrieved chunk.

        Args:
            chunk_id: Target chunk primary key.
            was_useful: ``True`` for positive, ``False`` for negative.
            user_id: Multi-tenancy identifier. Defaults to :attr:`user_id`.
            feedback_type: ``explicit``, ``implicit``, or ``repair``.
            tenant_id: Optional tenant override for this feedback event.
        """
        uid = user_id or self.user_id
        self._write_feedback(
            chunk_id, 1 if was_useful else 0, uid, feedback_type, tenant_id=tenant_id
        )
        self._maybe_learn_weights(uid)

    def learn_weights(self, user_id: str | None = None) -> dict[str, float]:
        """Force an immediate V(m) weight update from feedback history.

        Returns:
            New learned weights dictionary.
        """
        uid = user_id or self.user_id
        return self._maybe_learn_weights(uid, force=True)

    def _log_implicit_feedback(
        self, chunk_id: int, positive: bool = True, tenant_id: str | None = None
    ) -> None:
        """Write an implicit feedback row."""
        self._write_feedback(
            chunk_id,
            1 if positive else 0,
            self.user_id,
            "implicit",
            tenant_id=tenant_id,
        )

    def _write_feedback(
        self,
        chunk_id: int,
        positive: int,
        user_id: str,
        feedback_type: str,
        tenant_id: str | None = None,
    ) -> None:
        """Insert a row into ``feedback_log``."""
        tid = tenant_id if tenant_id is not None else self.tenant_id
        if _tenant_id_supported(self.conn):
            if tid != "default":
                self.config.assert_licensed("multi_tenant")
            owner = self.conn.execute(
                "SELECT 1 FROM chunk WHERE chunk_id = ? AND tenant_id = ?",
                (chunk_id, tid),
            ).fetchone()
            if owner is None:
                raise FeedbackLogError("chunk does not belong to the selected tenant")
            self.conn.execute(
                """INSERT INTO feedback_log (chunk_id, user_id, positive, feedback_type, created_at, tenant_id)
                   VALUES (?, ?, ?, ?, unixepoch(), ?)""",
                (chunk_id, user_id, positive, feedback_type, tid),
            )
        else:
            self.conn.execute(
                """INSERT INTO feedback_log (chunk_id, user_id, positive, feedback_type, created_at)
                   VALUES (?, ?, ?, ?, unixepoch())""",
                (chunk_id, user_id, positive, feedback_type),
            )
        self.conn.commit()
        logger.info("feedback_logged", chunk_id=chunk_id, positive=positive, type=feedback_type)

    def _maybe_learn_weights(self, user_id: str, force: bool = False) -> dict[str, float]:
        """Update V(m) weights when enough feedback exists."""
        try:
            # Count feedback signals for this user
            count_row = self.conn.execute(
                "SELECT COUNT(*) FROM feedback_log WHERE user_id = ?",
                (user_id,),
            ).fetchone()
            if not force and (count_row is None or count_row[0] < 10):
                return DEFAULT_WEIGHTS.copy()

            new_weights = learn_weights_from_feedback(self.conn, user_id=user_id)
            update_vm_weights(self.conn, user_id, new_weights)
            self.conn.commit()
            logger.info("vm_weights_learned", user_id=user_id, weights=new_weights)
            return new_weights
        except Exception as exc:
            logger.warning("vm_weights_learn_failed", user_id=user_id, error=str(exc))
            return DEFAULT_WEIGHTS.copy()

    def close(self) -> None:
        """Close the connection if this instance created it."""
        if self._own_conn:
            self.conn.close()
