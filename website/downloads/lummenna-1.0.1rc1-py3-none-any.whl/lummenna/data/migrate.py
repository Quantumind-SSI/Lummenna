"""D4: Lightweight Schema Migration System.

Track schema version via PRAGMA user_version.
Run numbered .sql files in migrations/.
Current version = 1.
"""

import importlib
import sqlite3
from pathlib import Path

from lummenna.logging import get_console_logger

logger = get_console_logger(__name__)

MIGRATIONS_DIR = Path(__file__).parent / "migrations"
CURRENT_SCHEMA_VERSION = 6


def migrate(conn: sqlite3.Connection, target_version: int = CURRENT_SCHEMA_VERSION) -> None:
    """Apply pending migrations from current PRAGMA user_version to target_version."""
    current = conn.execute("PRAGMA user_version").fetchone()[0]
    if current >= target_version:
        logger.debug("migrate_already_at_target", current=current, target=target_version)
        return

    for v in range(current + 1, target_version + 1):
        sql_path = MIGRATIONS_DIR / f"{v:04d}.sql"
        py_path = MIGRATIONS_DIR / f"{v:04d}.py"
        if sql_path.exists():
            conn.executescript(sql_path.read_text(encoding="utf-8"))
            conn.execute(f"PRAGMA user_version = {v}")
            logger.info("migration_applied", from_version=current, to_version=v)
        elif py_path.exists():
            mod = importlib.import_module(f"lummenna.data.migrations.{v:04d}")
            mod.run(conn)
            conn.execute(f"PRAGMA user_version = {v}")
            logger.info("migration_applied", from_version=current, to_version=v)
        else:
            logger.warning("migration_missing", version=v, path=str(sql_path))
            break


def get_current_version(conn: sqlite3.Connection) -> int:
    return int(conn.execute("PRAGMA user_version").fetchone()[0])
