"""A3b: GraphChannel using NetworkX with a pure-SQLite BFS fallback.

Input wire: SQLite adjacency (locus/room/provenance edges)
Output wire: C2 (fusion engine)
"""

import sqlite3
from dataclasses import dataclass

from lummenna.logging import get_console_logger

logger = get_console_logger(__name__)


@dataclass(frozen=True)
class GraphHit:
    chunk_id: int
    depth: int
    path: list[int]


class GraphChannel:
    """Graph traversal backed by SQLite adjacency, with optional NetworkX acceleration."""

    @staticmethod
    def is_available(conn: sqlite3.Connection) -> bool:
        """Return ``True`` if there is enough data to build a useful graph."""
        try:
            row = conn.execute("SELECT COUNT(*) FROM chunk WHERE valid_to IS NULL").fetchone()
            return row is not None and row[0] >= 3
        except Exception as exc:
            logger.debug("graph_availability_check_failed", error=str(exc))
            return False

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self._nx = None
        try:
            import networkx as nx

            self._nx = nx
            self._build_nx_graph()
        except Exception as exc:
            logger.debug("networkx_import_failed", error=str(exc))

    def _build_nx_graph(self):
        if self._nx is None:
            return
        self._graph = self._nx.DiGraph()
        # Build edges from provenance parent links and room/locus relationships
        rows = self.conn.execute(
            "SELECT chunk_id, locus_id, room_id, provenance_root FROM chunk WHERE valid_to IS NULL"
        ).fetchall()
        chunk_to_locus = {}
        chunk_to_room = {}
        for cid, lid, rid, _prov in rows:
            self._graph.add_node(cid)
            chunk_to_locus[cid] = lid
            chunk_to_room[cid] = rid
        # Locus-level edges
        locus_groups: dict = {}
        for cid, lid, _, _ in rows:
            if lid is not None:
                locus_groups.setdefault(lid, []).append(cid)
        for _lid, cids in locus_groups.items():
            for i in range(len(cids)):
                for j in range(i + 1, len(cids)):
                    self._graph.add_edge(cids[i], cids[j])
                    self._graph.add_edge(cids[j], cids[i])
        # Provenance parent edges
        prov_rows = self.conn.execute(
            "SELECT chunk_id, parent_provenance FROM provenance WHERE parent_provenance IS NOT NULL"
        ).fetchall()
        for cid, parent in prov_rows:
            parent_chunk = self.conn.execute(
                "SELECT chunk_id FROM provenance WHERE provenance_id = ?", (parent,)
            ).fetchone()
            if parent_chunk:
                self._graph.add_edge(parent_chunk[0], cid)

    def traverse_from_seed(self, seed_chunk_id: int, hops: int = 2) -> list[GraphHit]:
        """BFS traversal from seed with depth limit."""
        if self._nx is not None and hasattr(self, "_graph"):
            return self._traverse_nx(seed_chunk_id, hops)
        return self._traverse_sqlite(seed_chunk_id, hops)

    def _traverse_nx(self, seed_chunk_id: int, hops: int) -> list[GraphHit]:
        # The NetworkX graph is a snapshot built once at construction
        # (``_build_nx_graph``), while dense-channel seeds come from the vector
        # index. The two stores can drift: a chunk present in the vector store
        # may be absent from the graph snapshot (stored after the snapshot was
        # built, or tombstoned since). ``DiGraph.neighbors`` raises
        # ``NetworkXError: The node <id> is not in the digraph`` for a missing
        # node, which previously crashed search/assemble. Guard membership at
        # every access, mirroring the proven pattern in ``spreading.py`` — a
        # missing seed simply yields no graph-channel hits rather than an error.
        if seed_chunk_id not in self._graph:
            logger.debug("graph_seed_not_in_snapshot", seed_chunk_id=seed_chunk_id)
            return []
        hits = []
        visited = {seed_chunk_id: [seed_chunk_id]}
        queue = [(seed_chunk_id, 0)]
        while queue:
            node, depth = queue.pop(0)
            if depth >= hops:
                continue
            if node not in self._graph:
                # Defensive: a node can only enter the queue as a confirmed
                # neighbor of an in-graph node, so this should not happen — but
                # guard anyway so traversal can never raise on graph drift.
                continue
            for neighbor in self._graph.neighbors(node):
                if neighbor not in visited:
                    path = visited[node] + [neighbor]
                    visited[neighbor] = path
                    queue.append((neighbor, depth + 1))
                    hits.append(GraphHit(neighbor, depth + 1, path))
        return hits

    def _traverse_sqlite(self, seed_chunk_id: int, hops: int) -> list[GraphHit]:
        """Pure SQLite BFS fallback."""
        hits = []
        visited = {seed_chunk_id}
        queue = [(seed_chunk_id, 0, [seed_chunk_id])]
        while queue:
            node, depth, path = queue.pop(0)
            if depth >= hops:
                continue
            # Neighbors: same locus
            locus_row = self.conn.execute(
                "SELECT locus_id, room_id FROM chunk WHERE chunk_id = ?", (node,)
            ).fetchone()
            if locus_row is None:
                continue
            lid, rid = locus_row
            neighbors: set[int] = set()
            if lid is not None:
                rows = self.conn.execute(
                    "SELECT chunk_id FROM chunk WHERE locus_id = ? AND valid_to IS NULL", (lid,)
                ).fetchall()
                neighbors.update(r[0] for r in rows)
            if rid is not None:
                rows = self.conn.execute(
                    "SELECT chunk_id FROM chunk WHERE room_id = ? AND valid_to IS NULL", (rid,)
                ).fetchall()
                neighbors.update(r[0] for r in rows)
            # Parent provenance neighbors
            prov_rows = self.conn.execute(
                """SELECT p2.chunk_id
                    FROM provenance p1
                    JOIN provenance p2 ON p1.parent_provenance = p2.provenance_id
                    WHERE p1.chunk_id = ?""",
                (node,),
            ).fetchall()
            neighbors.update(r[0] for r in prov_rows if r[0] is not None)
            for n in neighbors:
                if n not in visited and n != node:
                    visited.add(n)
                    new_path = path + [n]
                    queue.append((n, depth + 1, new_path))
                    hits.append(GraphHit(n, depth + 1, new_path))
        return hits
